package com.example.labsupabase

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.rpc

object AcopioRepository {
    private val db = SupabaseConfig.client

    suspend fun listarProductores(): List<Productor> =
        db.from("productores").select {
            order("nombres", Order.ASCENDING)
        }.decodeList<Productor>()

    suspend fun guardarProductor(datos: NuevoProductor) {
        db.from("productores").insert(datos)
    }

    suspend fun guardarEntrega(datos: NuevaEntrega) {
        db.from("entregas").insert(datos)
    }

    suspend fun pendientes(productorId: Long): List<Entrega> =
        db.from("entregas_pendientes").select {
            filter { eq("productor_id", productorId) }
            order("fecha", Order.ASCENDING)
        }.decodeList<Entrega>()

    suspend fun liquidar(productorId: Long): Long =
        db.postgrest.rpc("generar_liquidacion", ParamProductor(productorId))
            .decodeAs<Long>()

    suspend fun historial(productorId: Long): List<Liquidacion> =
        db.from("liquidaciones").select {
            filter { eq("productor_id", productorId) }
            order("id", Order.DESCENDING)
        }.decodeList<Liquidacion>()

    suspend fun detalle(liquidacionId: Long): List<DetalleLiquidacion> =
        db.from("detalle_liquidacion").select {
            filter { eq("liquidacion_id", liquidacionId) }
            order("id", Order.ASCENDING)
        }.decodeList<DetalleLiquidacion>()

    suspend fun pagar(liquidacionId: Long): Long =
        db.postgrest.rpc("marcar_pagado", ParamLiquidacion(liquidacionId))
            .decodeAs<Long>()
}