package com.example.labsupabase

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class ProductoresActivity : AppCompatActivity() {

    private lateinit var codigoField: EditText
    private lateinit var nombresField: EditText
    private lateinit var comunidadField: EditText
    private lateinit var telefonoField: EditText
    private lateinit var guardarButton: Button
    private lateinit var listarButton: Button
    private lateinit var listaText: TextView
    private lateinit var historialLocalText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_productores)

        codigoField = findViewById(R.id.codigoField)
        nombresField = findViewById(R.id.nombresField)
        comunidadField = findViewById(R.id.comunidadField)
        telefonoField = findViewById(R.id.telefonoField)
        guardarButton = findViewById(R.id.guardarButton)
        listarButton = findViewById(R.id.listarButton)
        listaText = findViewById(R.id.listaText)
        historialLocalText = findViewById(R.id.historialLocalText)

        mostrarHistorialSharedPreferences()
        cargarProductores()

        listarButton.setOnClickListener { cargarProductores() }

        guardarButton.setOnClickListener {
            val codigo = codigoField.text.toString().trim().uppercase()
            val nombres = nombresField.text.toString().trim()
            val comunidad = comunidadField.text.toString().trim()
            val telefono = telefonoField.text.toString().trim()

            if (codigo.isEmpty() || nombres.isEmpty() || comunidad.isEmpty()) {
                Toast.makeText(this, "Código, nombres y comunidad son obligatorios", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (telefono.isNotEmpty() && !telefono.matches(Regex("^\\d{9}$"))) {
                Toast.makeText(this, "El teléfono debe tener exactamente 9 dígitos", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                guardarButton.isEnabled = false
                try {
                    val nuevo = NuevoProductor(
                        codigo = codigo,
                        nombres = nombres,
                        comunidad = comunidad,
                        telefono = telefono.ifEmpty { null }
                    )
                    AcopioRepository.guardarProductor(nuevo)

                    // Guardado en SharedPreferences con Set<String> (requisito de rúbrica imagen)
                    guardarEnHistorialLocal(nombres)

                    Toast.makeText(this@ProductoresActivity, "Productor registrado con éxito", Toast.LENGTH_SHORT).show()
                    codigoField.text.clear()
                    nombresField.text.clear()
                    comunidadField.text.clear()
                    telefonoField.text.clear()
                    cargarProductores()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Toast.makeText(this@ProductoresActivity, "No se pudo guardar: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    guardarButton.isEnabled = true
                }
            }
        }
    }

    private fun cargarProductores() {
        lifecycleScope.launch {
            try {
                val lista = AcopioRepository.listarProductores()
                listaText.text = if (lista.isEmpty()) "No hay productores"
                else lista.joinToString("\n") { "${it.id} | ${it.codigo} | ${it.nombres}" }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@ProductoresActivity, "No se pudo consultar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun guardarEnHistorialLocal(nombre: String) {
        val prefs = getSharedPreferences("AcopioPrefs", Context.MODE_PRIVATE)
        val setActual = prefs.getStringSet("historial_nombres", emptySet())?.toMutableSet() ?: mutableSetOf()
        setActual.add(nombre)
        prefs.edit().putStringSet("historial_nombres", setActual).apply()
        mostrarHistorialSharedPreferences()
    }

    private fun mostrarHistorialSharedPreferences() {
        val prefs = getSharedPreferences("AcopioPrefs", Context.MODE_PRIVATE)
        val nombres = prefs.getStringSet("historial_nombres", emptySet()) ?: emptySet()
        if (nombres.isNotEmpty()) {
            historialLocalText.text = "Historial local (Set<String>): ${nombres.joinToString(", ")}"
        }
    }
}