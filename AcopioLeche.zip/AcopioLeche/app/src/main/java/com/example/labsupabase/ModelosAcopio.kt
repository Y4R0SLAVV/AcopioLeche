package com.example.labsupabase

import kotlinx.serialization.Serializable

@Serializable
data class Productor(
    val id: Long,
    val codigo: String,
    val nombres: String,
    val comunidad: String,
    val telefono: String? = null
)

@Serializable
data class NuevoProductor(
    val codigo: String,
    val nombres: String,
    val comunidad: String,
    val telefono: String? = null
)

@Serializable
data class Entrega(
    val id: Long,
    val productor_id: Long,
    val fecha: String,
    val turno: String,
    val litros: Double,
    val precio_litro: Double,
    val importe: Double
)

@Serializable
data class NuevaEntrega(
    val productor_id: Long,
    val fecha: String,
    val turno: String,
    val litros: Double,
    val precio_litro: Double
)

@Serializable
data class Liquidacion(
    val id: Long,
    val productor_id: Long,
    val fecha: String,
    val total: Double,
    val estado: String,
    val fecha_pago: String? = null
)

@Serializable
data class DetalleLiquidacion(
    val id: Long,
    val liquidacion_id: Long,
    val entrega_id: Long,
    val importe: Double
)

@Serializable
data class ParamProductor(val p_productor_id: Long)

@Serializable
data class ParamLiquidacion(val p_liquidacion_id: Long)