package com.example.labsupabase

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

object SupabaseConfig {
    val client = createSupabaseClient(
        supabaseUrl = "https://lfdjogiomglkefuhvcds.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmZGpvZ2lvbWdsa2VmdWh2Y2RzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI4NzEyMTEsImV4cCI6MjEwODQ0NzIxMX0.r1dd3-zLcYDuaYjxq-EdGIdnrKEEaKjzEclWpZFf4YE"
    ) {
        install(Postgrest)
        install(Auth)
    }
}