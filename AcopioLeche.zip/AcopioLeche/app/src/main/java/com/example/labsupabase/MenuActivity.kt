package com.example.labsupabase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.auth
import kotlinx.coroutines.launch

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // COMENTADO TEMPORALMENTE para evitar bucles si la sesión falla
        /*
        if (SupabaseConfig.client.auth.currentSessionOrNull() == null) {
            irALogin()
            return
        }
        */

        findViewById<Button>(R.id.btnProductores).setOnClickListener {
            startActivity(Intent(this@MenuActivity, ProductoresActivity::class.java))
        }

        findViewById<Button>(R.id.btnEntregas).setOnClickListener {
            startActivity(Intent(this@MenuActivity, EntregasActivity::class.java))
        }

        findViewById<Button>(R.id.btnLiquidaciones).setOnClickListener {
            startActivity(Intent(this@MenuActivity, LiquidacionesActivity::class.java))
        }

        findViewById<Button>(R.id.btnCerrarSesion).setOnClickListener {
            Toast.makeText(this@MenuActivity, "Cerrando sesión...", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                try {
                    SupabaseConfig.client.auth.signOut()
                    irALogin()
                } catch (e: Exception) {
                    Toast.makeText(this@MenuActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun irALogin() {
        val intent = Intent(this@MenuActivity, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}