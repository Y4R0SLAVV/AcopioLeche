package com.example.labsupabase

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Calendar

class EntregasActivity : AppCompatActivity() {

    private var productores: List<Productor> = emptyList()
    private lateinit var productorSpinner: Spinner
    private lateinit var fechaField: EditText
    private lateinit var turnoSpinner: Spinner
    private lateinit var litrosField: EditText
    private lateinit var precioField: EditText
    private lateinit var importeText: TextView
    private lateinit var vistaPreviaButton: Button
    private lateinit var guardarButton: Button
    private lateinit var listaText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entregas)

        productorSpinner = findViewById(R.id.productorSpinner)
        fechaField = findViewById(R.id.fechaField)
        turnoSpinner = findViewById(R.id.turnoSpinner)
        litrosField = findViewById(R.id.litrosField)
        precioField = findViewById(R.id.precioField)
        importeText = findViewById(R.id.importeText)
        vistaPreviaButton = findViewById(R.id.vistaPreviaButton)
        guardarButton = findViewById(R.id.guardarButton)
        listaText = findViewById(R.id.listaText)

        // Configurar Spinner de Turnos
        val turnos = listOf("Mañana", "Tarde")
        turnoSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, turnos)

        // Selector de Fecha (YYYY-MM-DD)
        fechaField.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val mes = (m + 1).toString().padStart(2, '0')
                val dia = d.toString().padStart(2, '0')
                fechaField.setText("$y-$mes-$dia")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        cargarProductores()

        vistaPreviaButton.setOnClickListener { calcularVistaPrevia() }

        guardarButton.setOnClickListener { guardarEntrega() }
    }

    private fun cargarProductores() {
        guardarButton.isEnabled = false
        lifecycleScope.launch {
            try {
                productores = AcopioRepository.listarProductores()
                val etiquetas = productores.map { "${it.codigo} - ${it.nombres}" }
                productorSpinner.adapter = ArrayAdapter(
                    this@EntregasActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    etiquetas
                )
                guardarButton.isEnabled = productores.isNotEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@EntregasActivity, "Error al cargar productores: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun decimalPositivo(texto: String): BigDecimal? {
        val n = texto.trim().replace(',', '.').toBigDecimalOrNull()
        return n?.takeIf { it > BigDecimal.ZERO && it.scale() <= 2 }
    }

    private fun calcularVistaPrevia(): Pair<BigDecimal, BigDecimal>? {
        val litros = decimalPositivo(litrosField.text.toString())
        val precio = decimalPositivo(precioField.text.toString())

        if (litros == null || precio == null) {
            Toast.makeText(this, "Ingrese litros y precio mayores a 0 (máx. 2 decimales)", Toast.LENGTH_LONG).show()
            return null
        }
        if (litros >= BigDecimal("100000000") || precio >= BigDecimal("1000000")) {
            Toast.makeText(this, "Valores exceden el límite permitido", Toast.LENGTH_LONG).show()
            return null
        }

        val importe = litros.multiply(precio).setScale(2, RoundingMode.HALF_UP)
        importeText.text = "S/ ${importe.toPlainString()}"
        return Pair(litros, precio)
    }

    private fun guardarEntrega() {
        if (productores.isEmpty() || productorSpinner.selectedItemPosition == AdapterView.INVALID_POSITION) {
            Toast.makeText(this, "Seleccione un productor válido", Toast.LENGTH_SHORT).show()
            return
        }
        val fecha = fechaField.text.toString().trim()
        if (fecha.isEmpty()) {
            Toast.makeText(this, "Seleccione una fecha", Toast.LENGTH_SHORT).show()
            return
        }

        val valores = calcularVistaPrevia() ?: return
        val (litros, precio) = valores

        val posicion = productorSpinner.selectedItemPosition
        val productorId = productores[posicion].id
        val turno = if (turnoSpinner.selectedItemPosition == 0) "MANANA" else "TARDE"

        lifecycleScope.launch {
            guardarButton.isEnabled = false
            try {
                val nueva = NuevaEntrega(
                    productor_id = productorId,
                    fecha = fecha,
                    turno = turno,
                    litros = litros.toDouble(),
                    precio_litro = precio.toDouble()
                )
                AcopioRepository.guardarEntrega(nueva)
                Toast.makeText(this@EntregasActivity, "Entrega guardada correctamente", Toast.LENGTH_SHORT).show()
                listaText.text = "Última entrega registrada: ${productores[posicion].nombres} | $fecha ($turno) | ${importeText.text}"
                litrosField.text.clear()
                precioField.text.clear()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(
                    this@EntregasActivity,
                    "No se pudo registrar (verifique si ya existe entrega en esa fecha y turno): ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                guardarButton.isEnabled = true
            }
        }
    }
}