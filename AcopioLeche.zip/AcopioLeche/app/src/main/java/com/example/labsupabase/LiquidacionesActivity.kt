package com.example.labsupabase

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

class LiquidacionesActivity : AppCompatActivity() {

    private var productores: List<Productor> = emptyList()
    private var historialActual: List<Liquidacion> = emptyList()

    private lateinit var productorSpinner: Spinner
    private lateinit var pendientesButton: Button
    private lateinit var pendientesText: TextView
    private lateinit var liquidarButton: Button
    private lateinit var historialButton: Button
    private lateinit var historialText: TextView
    private lateinit var liquidacionIdField: EditText
    private lateinit var detalleButton: Button
    private lateinit var detalleText: TextView
    private lateinit var pagarButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liquidaciones)

        productorSpinner = findViewById(R.id.productorSpinner)
        pendientesButton = findViewById(R.id.pendientesButton)
        pendientesText = findViewById(R.id.pendientesText)
        liquidarButton = findViewById(R.id.liquidarButton)
        historialButton = findViewById(R.id.historialButton)
        historialText = findViewById(R.id.historialText)
        liquidacionIdField = findViewById(R.id.liquidacionIdField)
        detalleButton = findViewById(R.id.detalleButton)
        detalleText = findViewById(R.id.detalleText)
        pagarButton = findViewById(R.id.pagarButton)

        // 6. Cambiar productor: limpiar ID escrito y listas anteriores
        productorSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                liquidacionIdField.text.clear()
                pendientesText.text = ""
                historialText.text = ""
                detalleText.text = ""
                historialActual = emptyList()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        cargarProductores()

        pendientesButton.setOnClickListener { consultarPendientes() }
        liquidarButton.setOnClickListener { prepararLiquidacion() }
        historialButton.setOnClickListener { consultarHistorial() }
        detalleButton.setOnClickListener { consultarDetalle() }
        pagarButton.setOnClickListener { confirmarPago() }
    }

    private fun productorSeleccionado(): Productor? {
        val pos = productorSpinner.selectedItemPosition
        return if (productores.isNotEmpty() && pos != AdapterView.INVALID_POSITION) productores[pos] else null
    }

    private fun cargarProductores() {
        lifecycleScope.launch {
            try {
                productores = AcopioRepository.listarProductores()
                val etiquetas = productores.map { "${it.codigo} - ${it.nombres}" }
                productorSpinner.adapter = ArrayAdapter(
                    this@LiquidacionesActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    etiquetas
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error al cargar productores: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 1. Ver pendientes
    private fun consultarPendientes() {
        val prod = productorSeleccionado() ?: return
        lifecycleScope.launch {
            pendientesButton.isEnabled = false
            try {
                val lista = AcopioRepository.pendientes(prod.id)
                if (lista.isEmpty()) {
                    pendientesText.text = "No hay entregas pendientes"
                } else {
                    val totalLitros = lista.fold(BigDecimal.ZERO) { acc, e -> acc.add(BigDecimal.valueOf(e.litros)) }
                        .setScale(2, RoundingMode.HALF_UP)
                    val totalImporte = lista.fold(BigDecimal.ZERO) { acc, e -> acc.add(BigDecimal.valueOf(e.importe)) }
                        .setScale(2, RoundingMode.HALF_UP)

                    val filas = lista.joinToString("\n") {
                        "ID:${it.id} | ${it.fecha} | ${it.turno} | ${it.litros} L | S/ ${"%.2f".format(it.importe)}"
                    }
                    pendientesText.text = "$filas\nTotal: $totalLitros L | S/ $totalImporte"
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error al consultar pendientes: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                pendientesButton.isEnabled = true
            }
        }
    }

    // 2. Liquidar
    private fun prepararLiquidacion() {
        val prod = productorSeleccionado() ?: return
        lifecycleScope.launch {
            liquidarButton.isEnabled = false
            try {
                val lista = AcopioRepository.pendientes(prod.id)
                if (lista.isEmpty()) {
                    pendientesText.text = "No hay entregas pendientes"
                    Toast.makeText(this@LiquidacionesActivity, "No hay entregas pendientes para liquidar", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val totalImporte = lista.fold(BigDecimal.ZERO) { acc, e -> acc.add(BigDecimal.valueOf(e.importe)) }
                    .setScale(2, RoundingMode.HALF_UP)

                AlertDialog.Builder(this@LiquidacionesActivity)
                    .setTitle("Confirmar Liquidación")
                    .setMessage("Productor: ${prod.nombres}\nEntregas: ${lista.size}\nTotal a liquidar: S/ $totalImporte")
                    .setPositiveButton("Confirmar") { _, _ ->
                        ejecutarLiquidacion(prod.id)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error al verificar pendientes: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                liquidarButton.isEnabled = true
            }
        }
    }

    private fun ejecutarLiquidacion(productorId: Long) {
        lifecycleScope.launch {
            liquidarButton.isEnabled = false
            try {
                val idGenerado = AcopioRepository.liquidar(productorId)
                Toast.makeText(this@LiquidacionesActivity, "Liquidación generada con ID: $idGenerado", Toast.LENGTH_LONG).show()
                liquidacionIdField.setText(idGenerado.toString())
                consultarPendientes()
                consultarHistorial()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "No se pudo liquidar: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                liquidarButton.isEnabled = true
            }
        }
    }

    // 3. Ver historial
    private fun consultarHistorial() {
        val prod = productorSeleccionado() ?: return
        lifecycleScope.launch {
            historialButton.isEnabled = false
            try {
                historialActual = AcopioRepository.historial(prod.id)
                historialText.text = if (historialActual.isEmpty()) {
                    "Sin liquidaciones"
                } else {
                    historialActual.joinToString("\n") {
                        val pagoInfo = if (it.fecha_pago != null) " (${it.fecha_pago.take(10)})" else ""
                        "ID:${it.id} | ${it.fecha.take(10)} | S/ ${"%.2f".format(it.total)} | ${it.estado}$pagoInfo"
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error de consulta: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                historialButton.isEnabled = true
            }
        }
    }

    // 4. Ver detalle
    private fun consultarDetalle() {
        val prod = productorSeleccionado() ?: return
        val idTexto = liquidacionIdField.text.toString().trim()
        val liqId = idTexto.toLongOrNull()
        if (liqId == null) {
            Toast.makeText(this, "Ingrese un ID de liquidación válido", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            detalleButton.isEnabled = false
            try {
                if (historialActual.isEmpty()) {
                    historialActual = AcopioRepository.historial(prod.id)
                }
                if (historialActual.none { it.id == liqId }) {
                    Toast.makeText(this@LiquidacionesActivity, "El ID no pertenece al historial del productor seleccionado", Toast.LENGTH_LONG).show()
                    return@launch
                }

                val detalles = AcopioRepository.detalle(liqId)
                detalleText.text = if (detalles.isEmpty()) {
                    "Sin detalles"
                } else {
                    detalles.joinToString("\n") {
                        "Detalle #${it.id} -> Entrega ID: ${it.entrega_id} | S/ ${"%.2f".format(it.importe)}"
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error al consultar detalle: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                detalleButton.isEnabled = true
            }
        }
    }

    // 5. Marcar pagado
    private fun confirmarPago() {
        val prod = productorSeleccionado() ?: return
        val liqId = liquidacionIdField.text.toString().trim().toLongOrNull()
        if (liqId == null) {
            Toast.makeText(this, "Ingrese un ID de liquidación válido", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            pagarButton.isEnabled = false
            try {
                if (historialActual.isEmpty()) {
                    historialActual = AcopioRepository.historial(prod.id)
                }
                val liq = historialActual.find { it.id == liqId }
                if (liq == null) {
                    Toast.makeText(this@LiquidacionesActivity, "La liquidación no pertenece a este productor", Toast.LENGTH_LONG).show()
                    return@launch
                }
                if (liq.estado == "PAGADO") {
                    Toast.makeText(this@LiquidacionesActivity, "Esta liquidación ya está en estado PAGADO", Toast.LENGTH_LONG).show()
                    return@launch
                }

                AlertDialog.Builder(this@LiquidacionesActivity)
                    .setTitle("Confirmar Pago")
                    .setMessage("¿Desea registrar el pago de la liquidación #$liqId por S/ ${"%.2f".format(liq.total)}?")
                    .setPositiveButton("Marcar Pagado") { _, _ ->
                        ejecutarPago(liqId)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "Error al validar pago: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                pagarButton.isEnabled = true
            }
        }
    }

    private fun ejecutarPago(liqId: Long) {
        lifecycleScope.launch {
            pagarButton.isEnabled = false
            try {
                AcopioRepository.pagar(liqId)
                Toast.makeText(this@LiquidacionesActivity, "Pago registrado correctamente", Toast.LENGTH_SHORT).show()
                consultarHistorial()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LiquidacionesActivity, "No se pudo registrar pago: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                pagarButton.isEnabled = true
            }
        }
    }
}