package com.example.labsupabase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Asegúrate de que activity_main.xml sea tu diseño de Login (correo y clave)
        setContentView(R.layout.activity_main)

        val emailField = findViewById<EditText>(R.id.emailField) // Tu EditText de correo
        val passwordField = findViewById<EditText>(R.id.passwordField) // Tu EditText de contraseña
        val btnLogin = findViewById<Button>(R.id.btnLogin) // Tu botón de ingresar

        btnLogin.setOnClickListener {
            val email = emailField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Ingresa correo y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                btnLogin.isEnabled = false
                try {
                    // Iniciar sesión con Supabase
                    SupabaseConfig.client.auth.signInWith(Email) {
                        this.email = email
                        this.password = password
                    }

                    // Si el login es exitoso, viajamos al Menú
                    val intent = Intent(this@MainActivity, MenuActivity::class.java)
                    startActivity(intent)
                    finish() // Cerramos el login para no volver atrás

                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Error: Credenciales incorrectas", Toast.LENGTH_LONG).show()
                } finally {
                    btnLogin.isEnabled = true
                }
            }
        }
    }
}